primesieve 5.5.0
November 7, 2015
Kim Walisch, <kim.walisch@gmail.com>

About primesieve
================

  primesieve is a free software program that generates primes and
  prime k-tuplets (twin primes, prime triplets, ...) < 2^64 using a
  highly optimized implementation of the sieve of Eratosthenes.

  This is the console (terminal) version of primesieve there is also
  GUI version available at the homepage.

  Homepage: http://primesieve.org
  GitHub:   https://github.com/kimwalisch/primesieve

Usage
=====

  Open a terminal and run:

  $ ./primesieve 10000           Count the primes up to 10000
  $ ./primesieve 10000 --print   Print the primes up to 10000
  $ ./primesieve 1e9 2e9 -p2     Print the twin primes within [10^9, 2*10^9]
  $ ./primesieve 1e9 -d100 -c2   Count the twin primes within [10^9, 10^9+100]
  $ ./primesieve --help          Print the help menu
