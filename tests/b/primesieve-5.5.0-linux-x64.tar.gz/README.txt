primesieve 5.5.0
November 8, 2015
Kim Walisch, <kim.walisch@gmail.com>

About primesieve
================

  primesieve is a free software program that generates primes and
  prime k-tuplets (twin primes, prime triplets, ...) < 2^64 using a
  highly optimized implementation of the sieve of Eratosthenes.

  Homepage: http://primesieve.org
  GitHub:   https://github.com/kimwalisch/primesieve

Usage
=====

  By default primesieve counts prime numbers to print the primes set
  'Print->Prime numbers' in the menu bar.

  The best sieving performance is achieved with a sieve size of your
  CPU's L1 data cache size (usually 32 or 64 KB) when sieving < 10^17
  and a sieve size of your CPU's L2 cache size above.
